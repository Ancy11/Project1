# Property_Registration
This Project Uses Hyperledger Composer Playground to create Business network for property Registration.

Below are the artifacts for the network:

# Asset: 
 1. Property
 2. Property Listing
 
# Participant:
 User
 
# Transaction:
 1. Create Property
 2. Intent for Sale
 3. Purchase Property
 
